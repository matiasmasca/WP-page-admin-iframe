=== Gestion Grupos Plugin ===
Contributors: matiasmasca
Tags: iframe, embedded
Donate link: http://about.me/matiasmasca
Requires at least: 3.0.1
Tested up to: 3.6
Stable tag: 4.5
License: MIT
License URI: http://opensource.org/licenses/MIT

Plugin para mostrar una pagina web dentro de un iframe. Agrega un menú para el administrador del sitio.

== Description ==
Plugin para mostrar un iframe de una pagina web o aplicación web alojada en otro host.

Por ahora tenes que editar el pluggin para cambiar la URL de la pagina que queres motrar y podes cambiar el logo que muestra durante la carga.

Por cuestiones de seguridad aveces ese necesario agregar el dominio del sitio WordPress en la aplicación.

== Installation ==
1. Subir el archivo \"iframe_admin_page.php\"  en la carpeta \"/wp-content/plugins/\"
2. Activar el plugin desde el menú \"Plugins\" de WordPress.
3. Si todo salio bien, verás una nueva opcion en el menú del administrador.

Alternativo: comprimis en un .zip la carpeta con el nombre \"iframe_admin_page\" y lo instalas como cualquir otro pluggin de WordPress.

== Changelog ==
= 1.0 =
* Initial release.